# Basic_LFR_V3
Code for Basic line follower robot with maze solving, obstracle avoiding, wall follow etc. 
